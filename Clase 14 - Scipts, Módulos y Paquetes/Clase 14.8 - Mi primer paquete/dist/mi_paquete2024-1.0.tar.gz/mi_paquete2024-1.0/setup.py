from setuptools import setup

setup(

    name="mi_paquete2024",
    version="1.0",
    description="Este es mi primer paquete",
    author="Guido Soria",
    author_email="g.sorianantes@gmail.com",

    packages=["mi_primer_paquete"] # Es el nombre de la carpeta que será mi paquete

)