from mi_primer_paquete.modulo1 import Persona
from mi_primer_paquete.modulo2 import llamado_modulo2

persona1 = Persona("Nicolas", "Lopez")

print(persona1)

llamado_modulo2()