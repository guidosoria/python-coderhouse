from setuptools import setup

setup(
    name="Segunda_pre-entrega_Soria",
    version=1.0,
    description="Segunda pre entrega de curso de Python de Coderhouse",
    author="Guido Soria",
    author_email="g.sorianantes@gmail.com",
    
    packages=["Segunda_pre-entrega_Soria"]
)